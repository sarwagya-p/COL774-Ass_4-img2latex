import torch
import torch.nn as nn
import torch.nn.functional as F
from EncoderDecoder import EncoderCNN, DecoderRNN, EncoderDecoder
from data_utils import Img2LatexDataset
from train_model import *
import pickle

if __name__ == "__main__":
    model = load_model("./models/part1a.pt")
    

    